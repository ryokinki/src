CREATE TABLE "table" (
	`column1` VARCHAR(10),
	`column2` INTEGER
)
