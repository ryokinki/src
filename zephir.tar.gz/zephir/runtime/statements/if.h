
int zephir_statement_if(zephir_context *context, zval *statement TSRMLS_DC);