<?php
$this->someVariable["test"] = "test";
echo $this->someVariable["test"];
