<?php

class Test6Controller extends Phalcon\Mvc\Controller
{


}
