
int zephir_statement_break(zephir_context *context, zval *statement TSRMLS_DC);