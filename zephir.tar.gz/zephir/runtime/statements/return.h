
int zephir_statement_return(zephir_context *context, zval *statement TSRMLS_DC);