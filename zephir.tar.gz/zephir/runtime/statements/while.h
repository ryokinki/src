
int zephir_statement_while(zephir_context *context, zval *statement TSRMLS_DC);