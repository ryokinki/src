<?php

interface TestExInterface
{
}
