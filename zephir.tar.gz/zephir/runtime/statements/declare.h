
int zephir_statement_declare(zephir_context *context, zval *statement TSRMLS_DC);