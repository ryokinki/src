<?php

class Prueba extends Phalcon\Mvc\Model
{

}
