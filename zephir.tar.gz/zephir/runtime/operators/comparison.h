
zephir_compiled_expr *zephir_operator_comparison_greater(zephir_context *context, zval *expr TSRMLS_DC);
zephir_compiled_expr *zephir_operator_comparison_less(zephir_context *context, zval *expr TSRMLS_DC);