<?php

function igbinary_serialize($data)
{

}

function igbinary_unserialize($data)
{

}