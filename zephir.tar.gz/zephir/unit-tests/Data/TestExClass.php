<?php

class TestExClass
{
}
