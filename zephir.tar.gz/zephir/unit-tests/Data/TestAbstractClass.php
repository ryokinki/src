<?php

abstract class TestAbstractClass
{

}
