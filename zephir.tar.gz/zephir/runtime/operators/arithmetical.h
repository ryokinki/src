
zephir_compiled_expr *zephir_operator_arithmetical_add(zephir_context *context, zval *expr TSRMLS_DC);
zephir_compiled_expr *zephir_operator_arithmetical_mul(zephir_context *context, zval *expr TSRMLS_DC);
zephir_compiled_expr *zephir_operator_arithmetical_div(zephir_context *context, zval *expr TSRMLS_DC);