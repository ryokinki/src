<?php

class Imagick
{
	public function setImageAlphaChannel($channel)
	{

	}

	public function evaluateImage($x, $y, $z)
	{

	}

	public function newPseudoImage($x, $y, $z)
	{

	}

	public function newImage($x, $y)
	{

	}

	public function setColorspace($x)
	{

	}

	public function destroy()
	{

	}

	public function setImageDelay($x)
	{

	}

	public function compositeImage($a, $b, $c, $d)
	{

	}

	public function setIteratorIndex($a)
	{

	}

	public function nextImage()
	{

	}

	public function readImageBlob()
	{

	}

	public function setImageOpacity()
	{

	}

	public function clear()
	{

	}

	public function getImageAlphaChannel()
	{

	}

	public function setImageBackgroundColor()
	{

	}

    public static function getVersion()
	{

	}
}

class ImagickPixel
{

}

class ImagickDraw
{
	public function setFillColor()
	{

	}

	public function setFont()
	{

	}

	public function setFontSize()
	{

	}

	public function setfillopacity()
	{

	}

	public function setGravity()
	{

	}

	public function destroy()
	{

	}

}
